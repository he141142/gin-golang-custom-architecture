//go:build snowflake
// +build snowflake

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/database/snowflake"
)
