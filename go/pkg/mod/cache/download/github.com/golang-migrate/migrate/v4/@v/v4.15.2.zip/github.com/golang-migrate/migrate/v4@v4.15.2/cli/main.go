package main

import "github.com/golang-migrate/migrate/v4/internal/cli"

// Deprecated, please use cmd/migrate
func main() {
	cli.Main(Version)
}
