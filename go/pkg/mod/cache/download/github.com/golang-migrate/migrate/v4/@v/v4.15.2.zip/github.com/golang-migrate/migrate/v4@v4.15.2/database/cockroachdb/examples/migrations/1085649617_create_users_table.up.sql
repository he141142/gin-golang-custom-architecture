CREATE TABLE users (
  user_id INT UNIQUE,
  name    STRING(40),
  email   STRING(40)
);
