//go:build aws_s3
// +build aws_s3

package cli

import (
	_ "github.com/golang-migrate/migrate/v4/source/aws_s3"
)
