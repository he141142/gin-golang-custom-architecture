# Google Cloud Storage


## Import

```go
import (
  _ "github.com/golang-migrate/migrate/v4/source/google_cloud_storage"
 )
 ```

## Connection String

`gcs://<bucket>/<prefix>`
